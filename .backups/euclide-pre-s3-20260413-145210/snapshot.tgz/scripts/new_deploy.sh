#!/bin/bash

# new_deploy.sh — main.js 방식 문제 배포
# ============================================================================
# 기존 deploy.sh와 병용. main.js가 있는 문제를 R2에 배포.
# sketch.js 대신 main.js를 업로드하며, config.json 없이도 동작.
# ============================================================================

cd "$(dirname "$0")/.." || exit 1

BUCKET_NAME="euclide-geometry"
TARGET=$1

if [ -z "$TARGET" ]; then
    echo "Usage:"
    echo "  ./scripts/new_deploy.sh <problem_id>  # 특정 문제 배포"
    echo "  ./scripts/new_deploy.sh all            # main.js가 있는 모든 문제 배포"
    echo "  ./scripts/new_deploy.sh lib            # 라이브러리만 배포 (deploy.sh와 동일)"
    exit 1
fi

if ! command -v npx &> /dev/null; then
    echo "Error: npx not found."
    exit 1
fi

success_count=0
fail_count=0

get_file_hash() {
    local file=$1
    if [[ "$OSTYPE" == "darwin"* ]]; then
        md5 -q "$file"
    else
        md5sum "$file" | cut -d' ' -f1
    fi
}

get_r2_hash() {
    local path=$1
    local temp_file=$(mktemp)
    if npx wrangler r2 object get "$BUCKET_NAME/$path" --remote --pipe > "$temp_file" 2>/dev/null; then
        local hash=$(get_file_hash "$temp_file")
        rm -f "$temp_file"
        echo "$hash"
    else
        rm -f "$temp_file"
        echo ""
    fi
}

upload_if_changed() {
    local local_file=$1
    local r2_path=$2
    local content_type=$3
    local cache_control=$4

    if [ ! -f "$local_file" ]; then
        echo "  ⚠️  Skip: $local_file not found"
        return 1
    fi

    local local_hash=$(get_file_hash "$local_file")
    local r2_hash=$(get_r2_hash "$r2_path")

    if [ -n "$r2_hash" ] && [ "$local_hash" == "$r2_hash" ]; then
        echo "  ⏭️  Skip: $r2_path (unchanged)"
        return 0
    else
        echo "  ⬆️  Upload: $r2_path"
        if npx wrangler r2 object put "$BUCKET_NAME/$r2_path" \
            --file="$local_file" \
            --content-type="$content_type" \
            --cache-control="$cache_control" \
            --remote > /dev/null 2>&1; then
            ((success_count++))
            return 0
        else
            echo "  ❌ Failed: $r2_path"
            ((fail_count++))
            return 1
        fi
    fi
}

# main.js 방식 문제 배포
# 화이트리스트 방식: 아래 나열된 파일만 업로드
# .md, .tex, animation.md, note.md 등은 배포 대상 아님
deploy_problem() {
    local id=$1
    local dir="problems/$id"

    if [ ! -f "$dir/main.js" ]; then
        echo "  ⚠️  $dir/main.js 없음 — 기존 방식 문제. deploy.sh 사용."
        return 1
    fi

    echo "=== 문제 $id 배포 (main.js 방식) ==="
    echo ""

    # main.js
    upload_if_changed \
        "$dir/main.js" \
        "problems/$id/main.js" \
        "application/javascript" \
        "public, max-age=300"

    # config.json (있는 경우 — index.json 카드용)
    if [ -f "$dir/config.json" ]; then
        upload_if_changed \
            "$dir/config.json" \
            "problems/$id/config.json" \
            "application/json" \
            "public, max-age=300"
    fi

    # problem.html (R2 일원화 — Vercel 배포 불필요)
    if [ -f "$dir/problem.html" ]; then
        upload_if_changed \
            "$dir/problem.html" \
            "problems/$id/problem.html" \
            "text/html; charset=utf-8" \
            "public, max-age=300"
    fi

    # solution*.html
    for solution_file in "$dir"/solution.html "$dir"/solution[0-9]*.html; do
        if [ -f "$solution_file" ]; then
            filename=$(basename "$solution_file")
            upload_if_changed \
                "$solution_file" \
                "problems/$id/$filename" \
                "text/html; charset=utf-8" \
                "public, max-age=300"
        fi
    done

    # thumbnail.png (있는 경우)
    if [ -f "$dir/thumbnail.png" ]; then
        upload_if_changed \
            "$dir/thumbnail.png" \
            "problems/$id/thumbnail.png" \
            "image/png" \
            "public, max-age=86400"
    fi

    echo "✓ 문제 $id 배포 완료"
    echo ""
}

# 메인 실행
echo "=== Cloudflare R2 배포 (main.js 방식) ==="
echo "Bucket: $BUCKET_NAME"
echo ""

deploy_index() {
    echo "=== index.json 배포 ==="
    upload_if_changed \
        "problems/index.json" \
        "problems/index.json" \
        "application/json" \
        "public, max-age=300"
    echo ""
}

case $TARGET in
    all)
        echo "main.js가 있는 문제 전체 배포"
        echo ""
        for dir in problems/*/; do
            if [ -d "$dir" ] && [ -f "$dir/main.js" ]; then
                id=$(basename "$dir")
                deploy_problem "$id"
            fi
        done
        deploy_index
        ;;
    index)
        deploy_index
        ;;
    lib)
        echo "라이브러리 배포는 deploy.sh를 사용하세요."
        echo "  ./scripts/deploy.sh lib"
        exit 0
        ;;
    *)
        deploy_problem "$TARGET"
        deploy_index
        ;;
esac

echo "=== 배포 결과 ==="
echo "  성공: $success_count"
echo "  실패: $fail_count"
echo ""

if [ $fail_count -gt 0 ]; then
    echo "일부 파일 배포 실패"
    exit 1
fi

echo "배포 완료!"
echo ""

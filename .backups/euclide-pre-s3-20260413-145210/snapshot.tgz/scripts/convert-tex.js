#!/usr/bin/env node
/**
 * LaTeX to HTML converter using MathJax
 * Converts problem.tex and solution.tex files to pre-rendered HTML
 */

const fs = require('fs');
const path = require('path');

// MathJax configuration
require('mathjax').init({
    loader: { load: ['input/tex', 'output/svg'] },
    tex: {
        inlineMath: [['$', '$']],
        displayMath: [['$$', '$$'], ['\\[', '\\]']],
        processEscapes: true,
        packages: { '[+]': ['ams'] },
        macros: {
            wideparen: ['\\overparen{#1}', 1]
        }
    },
    svg: {
        fontCache: 'local'
    }
}).then((MathJax) => {
    main(MathJax);
}).catch((err) => {
    console.error('MathJax initialization failed:', err);
    process.exit(1);
});

async function main(MathJax) {
    const args = process.argv.slice(2);
    const convertAll = args.includes('--all');
    const specificProblem = args.find(arg => /^\d{3}$/.test(arg));

    const problemsDir = path.join(__dirname, '..', 'problems');

    if (!fs.existsSync(problemsDir)) {
        console.error('Problems directory not found:', problemsDir);
        process.exit(1);
    }

    const problemDirs = fs.readdirSync(problemsDir)
        .filter(dir => /^\d{3}$/.test(dir))
        .filter(dir => !specificProblem || dir === specificProblem)
        .sort();

    console.log(`Found ${problemDirs.length} problem(s) to process\n`);

    for (const problemDir of problemDirs) {
        const problemPath = path.join(problemsDir, problemDir);
        await convertProblemDir(MathJax, problemPath, problemDir);
    }

    console.log('\nConversion complete!');
}

async function convertProblemDir(MathJax, dirPath, problemId) {
    console.log(`Processing problem ${problemId}...`);

    // Find all .tex files
    const texFiles = fs.readdirSync(dirPath)
        .filter(file => file.endsWith('.tex'));

    for (const texFile of texFiles) {
        const texPath = path.join(dirPath, texFile);
        const htmlFile = texFile.replace('.tex', '.html');
        const htmlPath = path.join(dirPath, htmlFile);

        try {
            const html = await convertTexToHtml(MathJax, texPath);
            fs.writeFileSync(htmlPath, html, 'utf8');
            console.log(`  ${texFile} -> ${htmlFile}`);
        } catch (err) {
            console.error(`  Error converting ${texFile}:`, err.message);
        }
    }
}

async function convertTexToHtml(MathJax, texPath) {
    const texContent = fs.readFileSync(texPath, 'utf8');

    // Remove comment lines (starting with %)
    const lines = texContent.split('\n')
        .filter(line => !line.trim().startsWith('%'));

    // Join lines
    let content = lines.join('\n').trim();

    // Convert LaTeX commands to placeholders (before removing \\)
    const { text: processedContent, placeholders, blockPlaceholders } = convertLatexCommands(content);

    // Remove LaTeX line breaks (\\) only outside math environments
    const cleanedContent = removeLineBreaksOutsideMath(processedContent);

    // Convert LaTeX math to SVG
    let html = await convertMathToSvg(MathJax, cleanedContent, blockPlaceholders);

    // Restore HTML placeholders
    html = restorePlaceholders(html, placeholders);

    return html;
}

/**
 * Convert LaTeX structural commands to placeholders
 * Returns { text, placeholders, blockPlaceholders } where placeholders will be restored after math conversion
 * blockPlaceholders contains only block-level placeholders for paragraph splitting
 */
function convertLatexCommands(text) {
    const placeholders = [];
    const blockPlaceholders = [];
    let index = 0;

    // \section*{...} -> placeholder (block-level)
    text = text.replace(/\\section\*?\{([^}]+)\}/g, (match, content) => {
        const placeholder = `__HTML_PLACEHOLDER_${index++}__`;
        placeholders.push({ placeholder, html: `<h2>${content}</h2>` });
        blockPlaceholders.push(placeholder);
        return placeholder;
    });

    // \textbf{...} \\ -> placeholder with line break (theorem title, block-level)
    text = text.replace(/\\textbf\{([^}]+)\}\s*\\\\/g, (match, content) => {
        const placeholder = `__HTML_PLACEHOLDER_${index++}__`;
        placeholders.push({ placeholder, html: `<strong class="theorem-title">${content}</strong><br>` });
        blockPlaceholders.push(placeholder);
        return placeholder;
    });

    // \textbf{...} -> placeholder (inline, NOT block-level)
    text = text.replace(/\\textbf\{([^}]+)\}/g, (match, content) => {
        const placeholder = `__HTML_PLACEHOLDER_${index++}__`;
        placeholders.push({ placeholder, html: `<strong>${content}</strong>` });
        // NOT added to blockPlaceholders - stays inline
        return placeholder;
    });

    // \underline{...} -> placeholder (inline, NOT block-level)
    text = text.replace(/\\underline\{([^}]+)\}/g, (match, content) => {
        const placeholder = `__HTML_PLACEHOLDER_${index++}__`;
        placeholders.push({ placeholder, html: `<u>${content}</u>` });
        // NOT added to blockPlaceholders - stays inline
        return placeholder;
    });

    return { text, placeholders, blockPlaceholders };
}

/**
 * Restore HTML placeholders after escaping
 */
function restorePlaceholders(html, placeholders) {
    for (const { placeholder, html: replacement } of placeholders) {
        html = html.replace(placeholder, replacement);
    }
    return html;
}

/**
 * Remove LaTeX line breaks (\\) only outside math environments
 */
function removeLineBreaksOutsideMath(text) {
    // Match math regions: $$...$$, \[...\], \begin{...}...\end{...}, $...$
    const mathRegion = /\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|\\begin\{[^}]+\}[\s\S]*?\\end\{[^}]+\}|\$[^$]+\$/g;
    const regions = [];
    let m;
    while ((m = mathRegion.exec(text)) !== null) {
        regions.push({ start: m.index, end: m.index + m[0].length });
    }

    let result = '';
    let pos = 0;
    // Walk through text; inside math regions keep as-is, outside strip \\
    const sortedRegions = regions.sort((a, b) => a.start - b.start);
    for (const region of sortedRegions) {
        if (pos < region.start) {
            result += text.slice(pos, region.start).replace(/\\\\/g, '');
        }
        result += text.slice(region.start, region.end);
        pos = region.end;
    }
    if (pos < text.length) {
        result += text.slice(pos).replace(/\\\\/g, '');
    }
    return result;
}

async function convertMathToSvg(MathJax, text, blockPlaceholders = []) {
    // Pattern to match inline math $...$ and display math $$...$$ or \[...\]
    const mathPatterns = [
        { regex: /\$\$([^$]+)\$\$/g, display: true },
        { regex: /\\\[([\s\S]*?)\\\]/g, display: true },
        { regex: /\$([^$]+)\$/g, display: false }
    ];

    // Find all math expressions with their positions
    const mathMatches = [];

    // First, find display math ($$...$$, \[...\], \begin{env}...\end{env})
    let match;
    const displayRegex = /\$\$([^$]+)\$\$|\\\[([\s\S]*?)\\\]|(\\begin\{(?:align|equation|gather|multline)\*?\}[\s\S]*?\\end\{(?:align|equation|gather|multline)\*?\})/g;
    while ((match = displayRegex.exec(text)) !== null) {
        mathMatches.push({
            start: match.index,
            end: match.index + match[0].length,
            latex: match[1] || match[2] || match[3],
            display: true,
            original: match[0]
        });
    }

    // Then find inline math ($...$) but exclude those inside display math
    const inlineRegex = /\$([^$]+)\$/g;
    while ((match = inlineRegex.exec(text)) !== null) {
        const isInsideDisplay = mathMatches.some(m =>
            match.index >= m.start && match.index < m.end
        );
        if (!isInsideDisplay) {
            mathMatches.push({
                start: match.index,
                end: match.index + match[0].length,
                latex: match[1],
                display: false,
                original: match[0]
            });
        }
    }

    // Sort by position
    mathMatches.sort((a, b) => a.start - b.start);

    // Build result by processing segments
    let result = '';
    let currentPos = 0;

    for (const mathMatch of mathMatches) {
        // Add text before this math
        if (mathMatch.start > currentPos) {
            result += escapeHtml(text.slice(currentPos, mathMatch.start));
        }

        // Convert math to SVG
        try {
            const svg = await MathJax.tex2svg(mathMatch.latex, { display: mathMatch.display });
            const svgHtml = MathJax.startup.adaptor.outerHTML(svg);
            result += svgHtml;
        } catch (err) {
            console.error(`  Math conversion error: ${mathMatch.latex}`);
            result += `<span class="math-error">${escapeHtml(mathMatch.original)}</span>`;
        }

        currentPos = mathMatch.end;
    }

    // Add remaining text
    if (currentPos < text.length) {
        result += escapeHtml(text.slice(currentPos));
    }

    // Split display math and block-level placeholders out of paragraphs
    // Display math and headings should be block-level, not wrapped in <p> tags
    // Inline placeholders (\textbf, \underline without \\) stay within text flow
    const blockPlaceholderPattern = blockPlaceholders.length > 0
        ? blockPlaceholders.map(p => p.replace(/_/g, '_')).join('|')
        : '__NEVER_MATCH__';
    const blockRegex = new RegExp(
        `(<mjx-container[^>]*display="true"[^>]*>[\\s\\S]*?</mjx-container>|${blockPlaceholderPattern})`,
        'g'
    );

    // Split result into parts (block elements vs text)
    const parts = result.split(blockRegex).filter(s => s.trim());

    // Process each part
    const processed = parts.map(segment => {
        const trimmed = segment.trim();
        // If it's display math, don't wrap it
        if (trimmed.startsWith('<mjx-container') && trimmed.includes('display="true"')) {
            return trimmed;
        }
        // If it's a block-level placeholder (will become <h2> etc.), don't wrap it
        if (blockPlaceholders.includes(trimmed)) {
            return trimmed;
        }

        // For text segments, split by double newlines and wrap in <p>
        return segment
            .split('\n\n')
            .filter(p => p.trim())
            .map(p => `<p>${p.trim()}</p>`)
            .join('\n');
    });

    result = processed.join('\n');

    return result;
}

function escapeHtml(text) {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

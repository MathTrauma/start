#!/bin/bash
# problem.tex → config.json → index.json 메타데이터 동기화
# Usage: ./scripts/sync-metadata.sh <problem_id>
# Example: ./scripts/sync-metadata.sh 007

cd "$(dirname "$0")/.." || exit 1

# 등록된 카테고리 목록
REGISTERED_CATEGORIES=("닮음" "등적변환" "공원점" "내심과방심")

PROBLEM_ID=$1

if [ -z "$PROBLEM_ID" ]; then
  echo "Usage: ./scripts/sync-metadata.sh <problem_id>"
  echo "Example: ./scripts/sync-metadata.sh 007"
  echo ""
  echo "전체 동기화: ./scripts/sync-metadata.sh all"
  exit 1
fi

sync_problem() {
  local id=$1
  local PROBLEM_DIR="problems/$id"
  local TEX_FILE="$PROBLEM_DIR/problem.tex"
  local CONFIG_FILE="$PROBLEM_DIR/config.json"
  local INDEX_FILE="problems/index.json"

  if [ ! -f "$TEX_FILE" ]; then
    echo "  ⚠️  $TEX_FILE 없음"
    return 1
  fi

  if [ ! -f "$CONFIG_FILE" ]; then
    echo "  ⚠️  $CONFIG_FILE 없음"
    return 1
  fi

  # 1. problem.tex에서 level 추출 (첫 3줄에서 검색)
  # "level : theorem" → 0 (기본정리)
  # "level N" → N (숫자)
  if head -3 "$TEX_FILE" | grep -q "level.*:.*theorem"; then
    LEVEL=0
  else
    LEVEL=$(head -3 "$TEX_FILE" | grep -oE "level [0-9]" | head -1 | cut -d' ' -f2)
  fi

  if [ -z "$LEVEL" ]; then
    echo "  ⚠️  $id: level을 찾을 수 없음"
    return 1
  fi

  if [ "$LEVEL" = "0" ]; then
    echo "  $id: level 0 (기본정리)"
  else
    echo "  $id: level $LEVEL"
  fi

  # 2. 카테고리 추출 (CATEGORY 라인 또는 태그에서)
  ASSIGNED_CATEGORY=""

  # 2-1. CATEGORY 라인에서 추출
  CATEGORY=$(head -5 "$TEX_FILE" | grep "^% CATEGORY:" | sed 's/% CATEGORY: *//')

  # 2-2. 등록된 카테고리인지 확인
  for reg_cat in "${REGISTERED_CATEGORIES[@]}"; do
    if [ "$CATEGORY" = "$reg_cat" ]; then
      ASSIGNED_CATEGORY="$reg_cat"
      break
    fi
  done

  # 2-3. 등록되지 않은 경우, 태그에서 등록된 카테고리 찾기
  if [ -z "$ASSIGNED_CATEGORY" ]; then
    TAGS=$(head -5 "$TEX_FILE" | grep "^% #" | sed 's/% //' | tr '#' '\n' | tr -d ' ')
    for tag in $TAGS; do
      for reg_cat in "${REGISTERED_CATEGORIES[@]}"; do
        if [ "$tag" = "$reg_cat" ]; then
          ASSIGNED_CATEGORY="$reg_cat"
          break 2
        fi
      done
    done
  fi

  if [ -n "$ASSIGNED_CATEGORY" ]; then
    echo "    → 카테고리: $ASSIGNED_CATEGORY"
  fi

  # 3. config.json 업데이트 (level + categories)
  if [ -n "$ASSIGNED_CATEGORY" ]; then
    jq ".level = $LEVEL | .categories = (.categories // []) | if (.categories | index(\"$ASSIGNED_CATEGORY\")) then . else .categories += [\"$ASSIGNED_CATEGORY\"] end" "$CONFIG_FILE" > /tmp/config_$id.json && mv /tmp/config_$id.json "$CONFIG_FILE"
  else
    jq ".level = $LEVEL" "$CONFIG_FILE" > /tmp/config_$id.json && mv /tmp/config_$id.json "$CONFIG_FILE"
  fi

  # 4. solution.html 생성 (solution.tex → HTML 변환)
  local SOLUTION_TEX="$PROBLEM_DIR/solution.tex"
  local SOLUTION_HTML="$PROBLEM_DIR/solution.html"
  if [ -f "$SOLUTION_TEX" ]; then
    echo "    → solution.tex 변환 중..."
    node scripts/convert-tex.js "$id" > /dev/null 2>&1
    if [ -f "$SOLUTION_HTML" ]; then
      echo "    ✓ solution.html 생성됨"
    else
      echo "    ⚠ solution.html 생성 실패"
    fi
  fi

  # 5. index.json 업데이트 (level + categories)
  # 항목이 존재하면 업데이트, 없으면 추가
  EXISTING=$(jq ".problems[] | select(.id == \"$id\") | .id" "$INDEX_FILE" 2>/dev/null)

  if [ -n "$EXISTING" ]; then
    # 기존 항목 업데이트 (level)
    jq "(.problems[] | select(.id == \"$id\")) |= (.level = $LEVEL)" "$INDEX_FILE" > /tmp/index_$id.json && mv /tmp/index_$id.json "$INDEX_FILE"

    # 카테고리가 있으면 개별 항목과 categories 객체 모두 업데이트
    if [ -n "$ASSIGNED_CATEGORY" ]; then
      jq --arg cat "$ASSIGNED_CATEGORY" --arg id "$id" '
        (.problems[] | select(.id == $id) | .categories) |= (. // [] | if index($cat) then . else . + [$cat] end) |
        .categories[$cat] |= (. // [] | if index($id) then . else . + [$id] end | sort)
      ' "$INDEX_FILE" > /tmp/index_$id.json && mv /tmp/index_$id.json "$INDEX_FILE"
    fi
  else
    # 새 항목 추가
    echo "  → index.json에 새 항목 추가 중..."
    CONFIG_JSON=$(cat "$CONFIG_FILE")
    jq --argjson config "$CONFIG_JSON" '
      .problems += [{
        id: $config.id,
        title: $config.title,
        level: $config.level,
        tags: ($config.tags // []),
        categories: ($config.tags // []),
        url: ("viewer.html?problem=" + $config.id)
      } + (if $config.contest then {
        contest: true,
        contestName: ($config.contestName // null),
        contestProblem: ($config.contestProblem // null)
      } else {} end)]
      | .problems |= sort_by(.id)
    ' "$INDEX_FILE" > /tmp/index_$id.json && mv /tmp/index_$id.json "$INDEX_FILE"
  fi
}

echo "=== 메타데이터 동기화 ==="

if [ "$PROBLEM_ID" = "all" ]; then
  echo "전체 문제 동기화..."

  # 삭제된 문제 정리: index.json에는 있지만 디렉토리가 없는 항목 제거
  INDEX_FILE="problems/index.json"
  STALE_IDS=$(jq -r '.problems[].id' "$INDEX_FILE" | while read pid; do
    [ ! -d "problems/$pid" ] && echo "$pid"
  done)
  if [ -n "$STALE_IDS" ]; then
    for stale_id in $STALE_IDS; do
      echo "  🗑  index.json에서 삭제된 문제 $stale_id 제거"
      jq --arg id "$stale_id" '
        .problems |= map(select(.id != $id)) |
        (.categories // {}) |= with_entries(.value |= map(select(. != $id)))
      ' "$INDEX_FILE" > /tmp/index_cleanup.json && mv /tmp/index_cleanup.json "$INDEX_FILE"
    done
  fi

  for dir in problems/*/; do
    id=$(basename "$dir")
    sync_problem "$id"
  done
else
  sync_problem "$PROBLEM_ID"
fi

# 6. stats 재계산
echo -e "\nstats 재계산..."
INDEX_FILE="problems/index.json"

# level별 카운트 계산
level1=$(jq '[.problems[] | select(.level==1)] | length' "$INDEX_FILE")
level2=$(jq '[.problems[] | select(.level==2)] | length' "$INDEX_FILE")
level3=$(jq '[.problems[] | select(.level==3)] | length' "$INDEX_FILE")
total=$(jq '.problems | length' "$INDEX_FILE")

# stats 업데이트
jq ".stats.total = $total | .stats.byLevel.\"1\" = $level1 | .stats.byLevel.\"2\" = $level2 | .stats.byLevel.\"3\" = $level3" "$INDEX_FILE" > /tmp/index_stats.json && mv /tmp/index_stats.json "$INDEX_FILE"

echo "  Level 1: $level1"
echo "  Level 2: $level2"
echo "  Level 3: $level3"
echo "  Total: $total"

echo -e "\n동기화 완료!"

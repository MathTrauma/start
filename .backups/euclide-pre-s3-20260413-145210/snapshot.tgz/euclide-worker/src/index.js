/**
 * Euclide Geometry Worker
 * Serves files from R2 bucket with origin check, rate limiting, and bot protection
 */

// Rate limiting: 60 requests per minute per IP
const RATE_LIMIT_WINDOW = 60000; // 1 minute in ms
const RATE_LIMIT_MAX = 60;

// 무료 문제 목록
const FREE_PROBLEMS = ['050', '150', '200', '250', '300', '350', '400', '450', '900'];

// 무료 문제 판별: 기존 목록 + 레벨1(100번대) 10의 배수
function isFreeProblem(id) {
  if (FREE_PROBLEMS.includes(id)) return true;
  const num = parseInt(id, 10);
  return num >= 100 && num < 200 && num % 10 === 0;
}

// 각 레벨별 첫 번째 문제 캐시 (5분 TTL)
let firstProblemCache = null;
let firstProblemCacheTime = 0;
const FIRST_PROBLEM_CACHE_TTL = 5 * 60 * 1000;

async function isFirstProblemOfLevel(id, env) {
  const now = Date.now();
  if (!firstProblemCache || now - firstProblemCacheTime > FIRST_PROBLEM_CACHE_TTL) {
    try {
      const obj = await env.EUCLIDE_BUCKET.get('problems/index.json');
      if (obj) {
        const index = JSON.parse(await obj.text());
        const byLevel = {};
        for (const p of index.problems || []) {
          if (!byLevel[p.level]) byLevel[p.level] = [];
          byLevel[p.level].push(p.id);
        }
        firstProblemCache = new Set();
        for (const ids of Object.values(byLevel)) {
          ids.sort((a, b) => parseInt(a) - parseInt(b));
          firstProblemCache.add(ids[0]);
        }
        firstProblemCacheTime = now;
      }
    } catch {
      return false;
    }
  }
  return firstProblemCache ? firstProblemCache.has(id) : false;
}

// 통합 무료 판별 (기본 목록 + 레벨별 첫 문제)
async function isAccessFree(id, env) {
  if (isFreeProblem(id)) return true;
  return await isFirstProblemOfLevel(id, env);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return handleCORS();
    }

    // Handle root path
    if (path === '/' || path === '') {
      return new Response('Euclide Geometry API', {
        headers: getCORSHeaders()
      });
    }

    // ========== R2 File Serving ==========
    const filePath = path.slice(1); // Remove leading slash

    // Step 1: Origin/Referer check - mathtrauma.com만 허용
    const origin = request.headers.get('Origin');
    const referer = request.headers.get('Referer');
    const allowedDomains = ['mathtrauma.com', 'www.mathtrauma.com', 'localhost', '127.0.0.1'];

    const isAllowedOrigin = origin && allowedDomains.some(domain => origin.includes(domain));
    const isAllowedReferer = referer && allowedDomains.some(domain => referer.includes(domain));

    if (!isAllowedOrigin && !isAllowedReferer) {
      return new Response('직접 접근은 허용되지 않습니다.', {
        status: 403,
        headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }
      });
    }

    // Step 1.5: 문제 데이터 접근 제한
    // problems/XXX/ 경로에서 XXX 추출
    const problemMatch = filePath.match(/^problems\/(\d+)\//);
    if (problemMatch) {
      try {
        const problemId = problemMatch[1];
        const isFree = await isAccessFree(problemId, env);

        if (!isFree) {
          // 유료 문제 - 인증 필요
          const authHeader = request.headers.get('Authorization');
          if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return new Response(JSON.stringify({ error: '유료 회원 전용 문제입니다. 로그인이 필요합니다.' }), {
              status: 401,
              headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...getCORSHeaders() }
            });
          }

          const token = authHeader.slice(7);
          const user = await verifySupabaseToken(token, env);
          if (!user) {
            return new Response(JSON.stringify({ error: '유효하지 않은 토큰입니다.' }), {
              status: 401,
              headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...getCORSHeaders() }
            });
          }

          // admin 역할 확인
          const profiles = await safeJsonFetch(
            `${env.SUPABASE_URL}/rest/v1/profiles?id=eq.${user.id}&select=role`,
            { headers: { 'apikey': env.SUPABASE_SERVICE_KEY, 'Authorization': `Bearer ${env.SUPABASE_SERVICE_KEY}` } }
          );
          const isAdmin = Array.isArray(profiles) && profiles.length > 0 && profiles[0].role === 'admin';

          if (!isAdmin) {
            // 유료 사용자인지 확인
            const purchases = await safeJsonFetch(
              `${env.SUPABASE_URL}/rest/v1/user_purchases?user_id=eq.${user.id}`,
              { headers: { 'apikey': env.SUPABASE_SERVICE_KEY, 'Authorization': `Bearer ${env.SUPABASE_SERVICE_KEY}` } }
            );
            const hasAccess = Array.isArray(purchases) && purchases.length > 0 &&
              purchases[0].has_full_access &&
              new Date(purchases[0].expires_at) > new Date();

            if (!hasAccess) {
              return new Response(JSON.stringify({ error: '유료 회원 전용 문제입니다. 결제가 필요합니다.' }), {
                status: 403,
                headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...getCORSHeaders() }
              });
            }
          }
        }
      } catch (error) {
        console.error('Access check error:', error);
        return new Response(JSON.stringify({ error: '일시적인 인증 오류가 발생했습니다. 잠시 후 다시 시도해주세요.' }), {
          status: 503,
          headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...getCORSHeaders() }
        });
      }
    }

    // Step 2: Rate limiting using Cloudflare Durable Objects or KV
    const clientIP = request.headers.get('CF-Connecting-IP') || 'unknown';
    const rateLimitKey = `ratelimit:${clientIP}`;

    try {
      // KV를 사용한 rate limiting (env.RATE_LIMIT_KV 필요) — KV 에러는 fail-open
      if (env.RATE_LIMIT_KV) {
        try {
          const { allowed } = await checkRateLimit(env.RATE_LIMIT_KV, rateLimitKey);
          if (!allowed) {
            return new Response(getChallengeHTML(), {
              status: 429,
              headers: { 'Content-Type': 'text/html; charset=utf-8', 'Retry-After': '60' }
            });
          }
        } catch (kvError) {
          console.error('Rate limit KV error (fail-open):', kvError);
        }
      }

      // Step 3: Cloudflare Bot Management (자동 봇 감지)
      const botScore = request.cf?.botManagement?.score || 100;

      // 봇 점수가 30 이하면 봇으로 간주 (0=확실한 봇, 100=확실한 사람)
      if (botScore < 30) {
        return new Response('봇으로 감지되었습니다.', {
          status: 403,
          headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
      }

      // Get file from R2
      const object = await env.EUCLIDE_BUCKET.get(filePath);

      if (object === null) {
        return new Response('File not found', {
          status: 404,
          headers: getCORSHeaders()
        });
      }

      // Determine content type
      const contentType = getContentType(filePath);

      // Return file with appropriate headers
      const headers = {
        ...getCORSHeaders(),
        'Content-Type': contentType,
        'Cache-Control': getCacheControl(filePath),
        'ETag': object.httpEtag
      };

      return new Response(object.body, { headers });

    } catch (error) {
      console.error('Error fetching from R2:', error);
      return new Response('Internal Server Error', {
        status: 500,
        headers: getCORSHeaders()
      });
    }
  }
};

// Rate limiting with KV
async function checkRateLimit(kv, key) {
  const now = Date.now();
  const data = await kv.get(key, { type: 'json' });

  if (!data) {
    await kv.put(key, JSON.stringify({ count: 1, resetTime: now + RATE_LIMIT_WINDOW }), {
      expirationTtl: 60
    });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }

  if (now > data.resetTime) {
    await kv.put(key, JSON.stringify({ count: 1, resetTime: now + RATE_LIMIT_WINDOW }), {
      expirationTtl: 60
    });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }

  if (data.count >= RATE_LIMIT_MAX) {
    return { allowed: false, remaining: 0 };
  }

  data.count++;
  await kv.put(key, JSON.stringify(data), { expirationTtl: 60 });
  return { allowed: true, remaining: RATE_LIMIT_MAX - data.count };
}

// Challenge HTML (Turnstile 사용)
function getChallengeHTML() {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>보안 확인</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    .challenge-box {
      background: white;
      padding: 3rem;
      border-radius: 16px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      text-align: center;
      max-width: 400px;
    }
    h1 { color: #333; margin-bottom: 1rem; }
    p { color: #666; margin-bottom: 2rem; line-height: 1.6; }
    .retry-btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      padding: 1rem 2rem;
      border-radius: 8px;
      font-size: 1rem;
      cursor: pointer;
      margin-top: 1rem;
    }
    .retry-btn:hover {
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="challenge-box">
    <h1>🔒 보안 확인</h1>
    <p>짧은 시간에 너무 많은 요청이 감지되었습니다.<br>잠시 후 다시 시도해주세요.</p>
    <p style="font-size: 0.9rem; color: #999;">Rate Limit: 60 requests per minute</p>
    <button class="retry-btn" onclick="window.location.reload()">다시 시도</button>
  </div>
</body>
</html>`;
}

// CORS headers
function getCORSHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Max-Age': '86400'
  };
}

function handleCORS() {
  return new Response(null, {
    status: 204,
    headers: getCORSHeaders()
  });
}

// Content type detection
function getContentType(path) {
  const ext = path.split('.').pop().toLowerCase();
  const types = {
    'js': 'application/javascript',
    'json': 'application/json',
    'css': 'text/css',
    'html': 'text/html',
    'tex': 'text/plain',
    'md': 'text/markdown',
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'svg': 'image/svg+xml',
    'txt': 'text/plain'
  };
  return types[ext] || 'application/octet-stream';
}

// Cache control based on file type
function getCacheControl(path) {
  // Versioned library files - cache for 1 year
  if (path.match(/lib\/.*\.v\d+\.\d+\.\d+\.(js|css)$/)) {
    return 'public, max-age=31536000, immutable';
  }

  // Library files without version - cache for 1 hour
  if (path.startsWith('lib/')) {
    return 'public, max-age=3600';
  }

  // Problem files - cache for 5 minutes
  if (path.startsWith('problems/')) {
    return 'public, max-age=300';
  }

  // Default - cache for 1 hour
  return 'public, max-age=3600';
}

// Supabase REST 호출 — 실패 시 예외를 던져 상위에서 503 처리
async function safeJsonFetch(url, init) {
  const res = await fetch(url, init);
  if (!res.ok) throw new Error(`Upstream ${res.status}: ${url}`);
  return await res.json();
}

// Supabase JWT 토큰 검증
async function verifySupabaseToken(token, env) {
  try {
    const response = await fetch(`${env.SUPABASE_URL}/auth/v1/user`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'apikey': env.SUPABASE_ANON_KEY
      }
    });

    if (!response.ok) return null;

    const user = await response.json();
    return user;
  } catch (error) {
    console.error('Token verification error:', error);
    return null;
  }
}
